﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.WordChecking
{
    /// <summary>
    /// Defines data fields for words with english and ukrainian translations
    /// </summary>
    public interface IWordData
    {
        string EnglshTranslation { get; }
        string UkrainianTranslation { get; }
    }
}
