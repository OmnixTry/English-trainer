﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnglishTrainer.WordChecking
{
    class Topic
    {
        private Word[] words;
        public class TopicCheckResult
        {
            public readonly bool[] CorrectAnswers;
            public readonly float CorrectPercentage;

            public TopicCheckResult(bool[] correctAnswers, float correctPercentage)
            {
                CorrectAnswers = correctAnswers;
                CorrectPercentage = correctPercentage;
            }
        }
        public Topic(Word[] words)
        {
            this.words = words;
        }

        public TopicCheckResult CheckTopic(string[] translations)
        {
            int numberOfWords = words.Length;
            int numberOfCorrectTranslations = 0;
            bool[] correctAnswers = new bool[numberOfWords];

            if (words.Length != translations.Length)
            {
                throw new NotImplementedException("Uneven arrays");
            }
            else
            {
                for(int i = 0; i< numberOfWords; i++)
                {
                    if (words[i].CheckTranslation(translations[i]))
                    {
                        numberOfCorrectTranslations++;
                        correctAnswers[i] = true;
                    }
                    else
                    {
                        correctAnswers[i] = false;
                    }
                }
            }

            return new TopicCheckResult(correctAnswers, numberOfCorrectTranslations / numberOfWords);
        }
        public string[] GetGivenWords()
        {
            string[] givenWords = new string[words.Length];
            for(int i = 0; i<words.Length; i++)
            {
                givenWords[i] = words[i].givenWord;
            }
            return givenWords;
        }
    }
}
