﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.WordChecking
{
    /// <summary>
    /// Represents a word that can bee put in a topic
    /// </summary>
    public interface IWord
    {
        /// <summary>
        /// Checks wether the translation you offer is correct or not.
        /// </summary>
        /// <param name="offeredTranslation">A translation you want to check</param>
        /// <returns>true if the offered translatio is correct, othervise false</returns>
        bool Check(string offeredTranslation);
        /// <summary>
        /// Returns the value? user is supposed to translate into a different language
        /// </summary>
        string GivenWord { get; }
        /// <summary>
        /// Stores information about the last check
        /// </summary>
        bool IsCorrect { get; }


    }
}
