﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.WordChecking
{
    class UkrainianToEnglishWord : AbstractWord
    {
        public override bool Check(string offeredWord)
        {
            return string.Equals(word.EnglshTranslation, offeredWord, StringComparison.CurrentCultureIgnoreCase);
        }

        public override string GivenWord { get { return word.UkrainianTranslation; } }

        public UkrainianToEnglishWord(IWordData dBWord) : base(dBWord) { }
    }
}
