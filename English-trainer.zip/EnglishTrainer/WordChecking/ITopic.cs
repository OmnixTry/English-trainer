﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnglishTrainer.DataBase;

namespace EnglishTrainer.WordChecking
{
    /// <summary>
    /// Defines a functional for word translation topic
    /// </summary>
    public interface ITopic
    {
        /// <summary>
        /// The name of the word topic.
        /// </summary>
        string TopicName { get; }
        /// <summary>
        /// The set of elements that make up this topic.
        /// </summary>
        IWord[] Words { get; }
        /// <summary>
        /// Checks all the words's results to find out the score for the topic.
        /// </summary>
        /// <returns>Fraction of correct answers</returns>
        float Check();
        /// <summary>
        /// Creates word of a type that a particular popic works with.
        /// </summary>
        /// <returns>A word that is used in the topic.</returns>
        IWord CreateWord(IWordData dBWord);
    }
}
