﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Documents;

namespace EnglishTrainer.WordChecking
{
    class Word
    {
        public readonly string givenWord;
        public readonly string translation;

        public Word(string givenWord, string translation)
        {
            this.givenWord = givenWord;
            this.translation = translation;
        }

        public bool CheckTranslation(string offeredTranslation)
        {
            return translation == offeredTranslation;
        }
    }
}
