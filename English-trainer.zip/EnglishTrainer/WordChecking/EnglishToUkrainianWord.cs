﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.WordChecking
{
    class EnglishToUkrainianWord : AbstractWord
    {
        public override bool Check(string offeredWord)
        {
            return IsCorrect = string.Equals(word.UkrainianTranslation, offeredWord, StringComparison.CurrentCultureIgnoreCase);
        }
        public override string GivenWord { get { return word.EnglshTranslation; } }

        public EnglishToUkrainianWord(IWordData dBWord) : base(dBWord) { }
    }
}
