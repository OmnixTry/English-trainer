﻿using EnglishTrainer.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EnglishTrainer.WordChecking
{
    public class EnglishToUkrainianTopic : AbstractTopic
    {
        public override IWord CreateWord(IWordData dBWord)
        {
            return new EnglishToUkrainianWord(dBWord);
        }
        public EnglishToUkrainianTopic(string topicName, IEnumerable<IWordData> dBWords) : base(topicName, dBWords) { }
    }
}
