﻿using EnglishTrainer.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.WordChecking
{
    class UkrainianToEnglishTopic : AbstractTopic
    {
        public override IWord CreateWord(IWordData dBWord)
        {
            return new UkrainianToEnglishWord(dBWord);
        }
        public UkrainianToEnglishTopic(string topicName, IEnumerable<IWordData> words) : base(topicName, words) { }
    }
}
