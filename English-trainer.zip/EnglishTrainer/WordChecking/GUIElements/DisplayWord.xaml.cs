﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EnglishTrainer.WordChecking.GUIElements
{
    /// <summary>
    /// Логика взаимодействия для DisplayWord.xaml
    /// </summary>
    public partial class DisplayWord : UserControl
    {
        public IWord Word { get; private set; }
        public bool IsCorrect { get { return Word.IsCorrect; } }
        private void Disable() { TranslationBox.IsReadOnly = true; }
        private void Eneable() { TranslationBox.IsReadOnly = false; }
        public DisplayWord(IWord word)
        {
            InitializeComponent();
            Word = word;
            OriginalWord.Text = word.GivenWord;
        }
        public bool Check()
        {
            bool result = Word.Check(TranslationBox.Text);
            Disable();
            displayImage(); 
            return result;

            void displayImage()
            {
                BitmapImage bitmapCorrectnessImage = new BitmapImage();
                if (result)
                {
                    bitmapCorrectnessImage.BeginInit();
                    bitmapCorrectnessImage.UriSource = new Uri("/img/right.png", UriKind.Relative);
                    bitmapCorrectnessImage.EndInit();

                    CorrectnessImage.Source = bitmapCorrectnessImage;
                }
                else
                {
                    bitmapCorrectnessImage.BeginInit();
                    bitmapCorrectnessImage.UriSource = new Uri("/img/wrong.png", UriKind.Relative);
                    bitmapCorrectnessImage.EndInit();

                    CorrectnessImage.Source = bitmapCorrectnessImage;
                }
            }

        }
        public void Clear()
        {
            Eneable();
            TranslationBox.Text = "";
            CorrectnessImage.Source = null;
        }
    }
}
