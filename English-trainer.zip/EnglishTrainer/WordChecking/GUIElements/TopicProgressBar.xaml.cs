﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EnglishTrainer.WordChecking.GUIElements
{
    /// <summary>
    /// Логика взаимодействия для TopicProgress.xaml
    /// </summary>
    public partial class TopicProgress : UserControl
    {
        public TopicProgress()
        {
            InitializeComponent();
        }

        public void SetProgress(int progressPercentage = 0)
        {
            TopicProgressText.Text = progressPercentage.ToString() + "%";
            TopicProgressBar.Value = progressPercentage;
        }
    }
}
