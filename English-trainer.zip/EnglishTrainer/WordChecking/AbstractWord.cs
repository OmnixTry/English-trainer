﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnglishTrainer.DataBase;

namespace EnglishTrainer.WordChecking
{
    abstract class AbstractWord : IWord
    {
        /// <summary>
        /// Stores the whole information about the word
        /// </summary>
        protected readonly IWordData word;
        public abstract bool Check(string offeredWord);
        public abstract string GivenWord { get; }
        public bool IsCorrect { get; protected set; }

        public AbstractWord(IWordData dBWord)
        {
            word = dBWord;
        }
    }
}
