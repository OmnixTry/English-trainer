﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnglishTrainer.DataBase;

namespace EnglishTrainer.WordChecking
{
    public abstract class AbstractTopic : ITopic
    {
        public string TopicName { get; private set; }
        public IWord[] Words { get; protected set; }
        public float Check()
        {
            int correct = 0;
            int numOfWords = Words.Count();
            foreach (IWord word in Words)
            {
                if (word.IsCorrect) correct++;
            }
            return correct / (float)numOfWords;
        }
        public AbstractTopic(string topicName)
        {
            TopicName = topicName;
        }
        public AbstractTopic(string topicName, IEnumerable<IWordData> words)
        {
            TopicName = topicName;
            Words = shuffle(createIWords());

            IWord[] createIWords()
            {
                int numberOfWords = words.Count();
                IWordData[] wordsToAdd = words.ToArray();
                IWord[] createdIWords = new IWord[numberOfWords];

                for (int i = 0; i < numberOfWords; i++)
                    createdIWords[i] = CreateWord(wordsToAdd[i]);

                return createdIWords;
            }

            IWord[] shuffle(IWord[] wordsToShuffle)
            {
                IWord buff;
                int swapPosition;
                Random random = new Random();
                
                for (int i = 2; i < wordsToShuffle.Length; i++)
                {
                    swapPosition = random.Next(i + 1);
                    buff = wordsToShuffle[swapPosition];
                    wordsToShuffle[swapPosition] = wordsToShuffle[i];
                    wordsToShuffle[i] = buff;
                }
                return wordsToShuffle;
            }
        }
        public abstract IWord CreateWord(IWordData dBWord);
    }
}
