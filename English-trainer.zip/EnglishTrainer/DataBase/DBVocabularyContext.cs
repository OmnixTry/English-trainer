﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace EnglishTrainer.DataBase
{
    class DBVocabularyContext : DbContext
    {
        public DBVocabularyContext() : 
            base("VocabularyDB") 
        { }
        public DbSet<DBWord> DBWords { get; set; }
        public DbSet<DBTopic> DBTopics { get; set; }
    }
}
