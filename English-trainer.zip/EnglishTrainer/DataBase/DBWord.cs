﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnglishTrainer.DataBase
{
    public class DBWord : EnglishTrainer.WordChecking.IWordData
    {
        public int Id { get; set; }
        public string EnglshTranslation { get; set; }
        public string UkrainianTranslation { get; set; }
        public DBTopic Topic { get; set; }
    }
}
