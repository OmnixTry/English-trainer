﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnglishTrainer.WordChecking;

namespace EnglishTrainer.DataBase
{
    public class DBWordLoader : IWordLoader
    {
        public IWordData[] LoadWordsOfTopics(params string[] topicName)
        {
            IEnumerable<DBWord> wordsOfTopics = new DBWord[0];
            using (DBVocabularyContext vocabulary = new DBVocabularyContext())
            {
                foreach (string name in topicName)
                {
                    // find the topic tith a particular name
                    // get it's words and append them to all the previous words
                    wordsOfTopics = wordsOfTopics.Concat(vocabulary.DBTopics.Include("DBWords").Where((x) =>  x.Name == name ).First().DBWords.ToArray());
                }
            }
            return wordsOfTopics.ToArray();
        }
    }
}
