﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BLL.DataTransferObjects
{
    public enum Language
    {
        Ukrainian,
        English
    }
}
