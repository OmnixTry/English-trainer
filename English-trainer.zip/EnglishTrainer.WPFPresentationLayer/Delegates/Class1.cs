﻿using EnglishTrainer.WPFPresentationLayer.TopicAdding;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishTrainer.WPFPresentationLayer.Delegates
{
    public delegate void wordDeleting(WordToAdd word);
}
